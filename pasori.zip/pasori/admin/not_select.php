<?php
require_once( __DIR__ . '/../session.php');
admin_session();
?>


<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NG</title>
</head>
<body>
<div class="mx-auto" style="width: 400px;">
    <br/><br/>スタッフが選択されていません<br/>
    <button class="btn btn-primary" onclick="history.back()">戻る</button>
</div>
</body>
</html>
